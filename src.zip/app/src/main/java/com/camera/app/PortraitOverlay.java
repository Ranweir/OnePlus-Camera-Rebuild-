package com.camera.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/**
 * Soft vignette shown in PORTRAIT mode only when the phone has no real bokeh
 * extension (when it has, CameraX turns on the hardware bokeh instead).
 */
public class PortraitOverlay extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public PortraitOverlay(Context c) { this(c, null); }

    public PortraitOverlay(Context c, AttributeSet a) {
        super(c, a);
        p.setShader(new RadialGradient(0f, 0f, 1f,
                new int[]{0x00000000, 0x00000000, 0x99000000},
                new float[]{0f, 0.55f, 1f},
                Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        c.save();
        c.translate(w / 2f, h * 0.48f);
        c.scale(w * 0.75f, h * 0.62f);
        c.drawRect(-4f, -4f, 4f, 4f, p);
        c.restore();
    }
}
