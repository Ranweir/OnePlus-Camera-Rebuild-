package com.camera.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.util.Range;
import android.view.Display;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraInfoUnavailableException;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExposureState;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.core.UseCase;
import androidx.camera.core.UseCaseGroup;
import androidx.camera.core.ViewPort;
import androidx.camera.core.ZoomState;
import androidx.camera.extensions.ExtensionMode;
import androidx.camera.extensions.ExtensionsManager;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FallbackStrategy;
import androidx.camera.video.MediaStoreOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.exifinterface.media.ExifInterface;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "CameraApp";
    private static final int ORANGE = 0xFFEF8A3F;
    private static final int ON_ORANGE = 0xFF1A0D00;

    private static final String[] MODES = {"MASTER", "VIDEO", "PHOTO", "PORTRAIT", "MORE"};
    private static final float[] ZP = {1f, 2f, 3f, 5f};
    private static final int[] TM = {0, 3, 5, 10};

    /** One captured photo / video in the gallery strip. */
    private static class Item {
        final Uri uri;
        final boolean video;
        final long date;
        Bitmap thumb;

        Item(Uri u, boolean v, long d) {
            uri = u;
            video = v;
            date = d;
        }
    }

    // ---- views ----
    private View root, vf, side, pop, fl, shi;
    private PreviewView previewView;
    private PortraitOverlay port;
    private GridOverlay grid;
    private ZoomDialView dial;
    private View focusRing, ringHd, msg, evPanel;
    private ImageButton bFl, bEv, bLv, bAi, bFo, bMn, bFi, bBt, fp;
    private View bHd, bTm, sh;
    private ImageView tmi, th;
    private TextView tmv, evv, rec, cd, msgText, pd, px, pt;
    private Button msgBtn;
    private SeekBar evr;
    private LinearLayout zr, modesRow;
    private HorizontalScrollView modesScroll;
    private FrameLayout pm;
    private final TextView[] zoomBtns = new TextView[ZP.length];
    private final Map<String, TextView> modeViews = new LinkedHashMap<>();
    private GradientDrawable shutterFill;

    // ---- camera state ----
    private Executor mainExec;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private ProcessCameraProvider cameraProvider;
    private ExtensionsManager extensionsManager;
    private Camera camera;
    private ImageCapture imageCapture;
    private VideoCapture<Recorder> videoCapture;
    private Recording recording;
    private OrientationEventListener orientationListener;
    private GestureDetector flingDetector;

    private int lensFacing = CameraSelector.LENS_FACING_BACK;
    private String mode = "PHOTO";
    private String boundKind = "";
    private boolean extActive = false;
    private boolean cameraStarting = false;
    private boolean permAsked = false;
    private int bindToken = 0;

    private float zoom = 1f;
    private float ev = 0f;
    private boolean flashOn = false;
    private boolean hdOn = false;
    private boolean beautyOn = false;
    private boolean gridOn = false;
    private int filterIdx = 0;
    private int timerSec = 3;
    private boolean busy = false;
    private boolean cancelCountdown = false;
    private boolean multiTouch = false;

    private final List<Item> items = new ArrayList<>();
    private int cur = 0;

    private final ActivityResultLauncher<String[]> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),
                    result -> onPermResult());

    // =====================================================================
    // lifecycle
    // =====================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);
        mainExec = ContextCompat.getMainExecutor(this);

        bindViews();
        setupInsets();
        setupTopBar();
        setupSide();
        setupZoomRow();
        setupModes();
        setupBottom();
        setupViewer();
        setupGestures();

        // TextureView based preview: reliable on every phone and lets us tint it for filters
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.getPreviewStreamState().observe(this, st -> {
            if (st == PreviewView.StreamState.STREAMING) hideMsg();
        });

        orientationListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int o) {
                if (o == ORIENTATION_UNKNOWN) return;
                int r;
                if (o >= 315 || o < 45) r = Surface.ROTATION_0;
                else if (o < 135) r = Surface.ROTATION_270;
                else if (o < 225) r = Surface.ROTATION_180;
                else r = Surface.ROTATION_90;
                if (imageCapture != null) imageCapture.setTargetRotation(r);
                if (videoCapture != null && recording == null) videoCapture.setTargetRotation(r);
            }
        };

        setMode("PHOTO");
        updateZoomUi();
        styleChip();
        loadExisting();
        requestPerms();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (orientationListener.canDetectOrientation()) orientationListener.enable();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (cameraProvider == null && has(Manifest.permission.CAMERA)) startCamera();
    }

    @Override
    protected void onStop() {
        super.onStop();
        orientationListener.disable();
        if (recording != null) recording.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        main.removeCallbacksAndMessages(null);
        io.shutdown();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (pop.getVisibility() == View.VISIBLE) closeViewer();
        else super.onBackPressed();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                && pop.getVisibility() != View.VISIBLE) {
            if (event.getRepeatCount() == 0) sh.performClick();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (flingDetector != null) flingDetector.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    // =====================================================================
    // view setup
    // =====================================================================

    private void bindViews() {
        root = findViewById(R.id.root);
        vf = findViewById(R.id.vf);
        previewView = findViewById(R.id.previewView);
        port = findViewById(R.id.port);
        grid = findViewById(R.id.grid);
        dial = findViewById(R.id.dial);
        focusRing = findViewById(R.id.focusRing);
        evPanel = findViewById(R.id.ev);
        evr = findViewById(R.id.evr);
        evv = findViewById(R.id.evv);
        rec = findViewById(R.id.rec);
        cd = findViewById(R.id.cd);
        fl = findViewById(R.id.fl);
        msg = findViewById(R.id.msg);
        msgText = findViewById(R.id.msgText);
        msgBtn = findViewById(R.id.msgBtn);
        side = findViewById(R.id.side);
        bFl = findViewById(R.id.bFl);
        bEv = findViewById(R.id.bEv);
        bLv = findViewById(R.id.bLv);
        bAi = findViewById(R.id.bAi);
        bFo = findViewById(R.id.bFo);
        bMn = findViewById(R.id.bMn);
        bHd = findViewById(R.id.bHd);
        ringHd = findViewById(R.id.ringHd);
        bFi = findViewById(R.id.bFi);
        bBt = findViewById(R.id.bBt);
        bTm = findViewById(R.id.bTm);
        tmi = findViewById(R.id.tmi);
        tmv = findViewById(R.id.tmv);
        zr = findViewById(R.id.zr);
        modesScroll = findViewById(R.id.modesScroll);
        modesRow = findViewById(R.id.modes);
        th = findViewById(R.id.th);
        sh = findViewById(R.id.sh);
        shi = findViewById(R.id.shi);
        fp = findViewById(R.id.fp);
        pop = findViewById(R.id.pop);
        pm = findViewById(R.id.pm);
        pd = findViewById(R.id.pd);
        px = findViewById(R.id.px);
        pt = findViewById(R.id.pt);

        shutterFill = new GradientDrawable();
        shutterFill.setShape(GradientDrawable.OVAL);
        shutterFill.setColor(ORANGE);
        shi.setBackground(shutterFill);

        tint(bFl, false);
        tint(bEv, false);
        tint(bLv, false);
        tint(bAi, false);
        tint(bFo, false);
        tint(bMn, false);
        tint(bFi, false);
        tint(bBt, false);
        fp.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
    }

    private void setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets b = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        WindowCompat.getInsetsController(getWindow(), root).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), root).setAppearanceLightNavigationBars(false);
    }

    private void setupTopBar() {
        bFl.setOnClickListener(v -> {
            flashOn = !flashOn;
            bFl.setImageResource(flashOn ? R.drawable.ic_flash_on : R.drawable.ic_flash_off);
            tint(bFl, flashOn);
            if (imageCapture != null) {
                imageCapture.setFlashMode(flashOn && isBack()
                        ? ImageCapture.FLASH_MODE_ON : ImageCapture.FLASH_MODE_OFF);
            }
            if (flashOn && isBack() && camera != null && !camera.getCameraInfo().hasFlashUnit()) {
                toast("Is camera me flash nahi hai");
            }
        });

        bEv.setOnClickListener(v -> {
            boolean on = evPanel.getVisibility() != View.VISIBLE;
            evPanel.setVisibility(on ? View.VISIBLE : View.GONE);
            tint(bEv, on);
        });

        evr.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                ev = (p - 20) / 10f;
                evv.setText(String.format(Locale.US, "%.1f", ev));
                applyEv();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) { }

            @Override
            public void onStopTrackingTouch(SeekBar s) { }
        });

        // These three were only visual toggles in the old UI; kept the same.
        for (final ImageButton b : new ImageButton[]{bLv, bAi, bFo}) {
            b.setOnClickListener(v -> {
                boolean on = !b.isSelected();
                b.setSelected(on);
                tint(b, on);
            });
        }

        bMn.setOnClickListener(v -> {
            gridOn = !gridOn;
            updateOverlays();
        });
    }

    private void setupSide() {
        bHd.setOnClickListener(v -> {
            hdOn = !hdOn;
            ringHd.setSelected(hdOn);
            if (recording == null) bindCamera(); // capture quality mode needs a rebind
        });

        bFi.setOnClickListener(v -> {
            filterIdx = (filterIdx + 1) % Filters.COUNT;
            tint(bFi, filterIdx > 0);
            applyLook();
        });

        bBt.setOnClickListener(v -> {
            beautyOn = !beautyOn;
            tint(bBt, beautyOn);
            applyLook();
        });
    }

    private void setupZoomRow() {
        for (int i = 0; i < ZP.length; i++) {
            TextView t = new TextView(this);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(14f);
            t.setTextColor(Color.WHITE);
            zr.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            zoomBtns[i] = t;
        }

        bTm.setOnClickListener(v -> {
            int idx = 0;
            for (int i = 0; i < TM.length; i++) if (TM[i] == timerSec) idx = i;
            timerSec = TM[(idx + 1) % TM.length];
            styleChip();
        });

        zr.setOnTouchListener(new View.OnTouchListener() {
            float x0, z0;
            boolean dragged;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        x0 = e.getX();
                        z0 = zoom;
                        dragged = false;
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getX() - x0;
                        if (Math.abs(dx) > dp(8)) dragged = true;
                        if (dragged) {
                            dial.setVisibility(View.VISIBLE);
                            setZoom((float) (z0 * Math.pow(2.0, dx / dp(110))));
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (!dragged) {
                            int idx = (int) (e.getX() / (v.getWidth() / (float) ZP.length));
                            idx = Math.max(0, Math.min(ZP.length - 1, idx));
                            setZoom(ZP[idx]);
                        }
                        dial.setVisibility(View.GONE);
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        dial.setVisibility(View.GONE);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void setupModes() {
        for (final String m : MODES) {
            TextView t = new TextView(this);
            t.setText(m);
            t.setTextSize(13f);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dpi(14), dpi(6), dpi(14), dpi(6));
            t.setClickable(true);
            t.setOnClickListener(v -> setMode(m));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dpi(1), 0, dpi(1), 0);
            modesRow.addView(t, lp);
            modeViews.put(m, t);
        }
        modesScroll.post(() -> {
            int pad = Math.max(0, modesScroll.getWidth() / 2 - dpi(40));
            modesRow.setPadding(pad, 0, pad, 0);
            scrollToActiveMode(false);
        });
    }

    private void setupBottom() {
        th.setOnClickListener(v -> {
            cur = 0;
            showViewer();
        });

        sh.setOnTouchListener((v, e) -> {
            if (recording == null) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    shi.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start();
                } else if (e.getAction() == MotionEvent.ACTION_UP
                        || e.getAction() == MotionEvent.ACTION_CANCEL) {
                    shi.animate().scaleX(1f).scaleY(1f).setDuration(80).start();
                }
            }
            return false;
        });
        sh.setOnClickListener(v -> onShutter());

        fp.setOnClickListener(v -> {
            if (recording != null || busy) return;
            lensFacing = isBack() ? CameraSelector.LENS_FACING_FRONT : CameraSelector.LENS_FACING_BACK;
            bindCamera();
        });
    }

    private void setupViewer() {
        px.setOnClickListener(v -> closeViewer());
        pd.setOnClickListener(v -> toast("Ye already Gallery me save hai (Pictures/Camera, Movies/Camera)"));
        pt.setOnClickListener(v -> deleteCurrent());

        flingDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (pop.getVisibility() != View.VISIBLE || items.size() < 2) return false;
                if (Math.abs(vx) > Math.abs(vy) * 1.5f && Math.abs(vx) > 900f) {
                    cur = vx < 0 ? Math.min(cur + 1, items.size() - 1) : Math.max(cur - 1, 0);
                    showViewer();
                    return true;
                }
                return false;
            }
        });
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupGestures() {
        final ScaleGestureDetector scale = new ScaleGestureDetector(this,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScale(ScaleGestureDetector d) {
                        setZoom(zoom * d.getScaleFactor());
                        return true;
                    }
                });
        final GestureDetector tap = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onSingleTapUp(MotionEvent e) {
                        if (!multiTouch) focusAt(e.getX(), e.getY());
                        return true;
                    }
                });
        previewView.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) multiTouch = false;
            if (e.getPointerCount() > 1) multiTouch = true;
            scale.onTouchEvent(e);
            if (!scale.isInProgress()) tap.onTouchEvent(e);
            return true;
        });
    }

    // =====================================================================
    // permissions
    // =====================================================================

    private boolean has(String p) {
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPerms() {
        List<String> need = new ArrayList<>();
        if (!has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
        if (!has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (need.isEmpty()) startCamera();
        else permLauncher.launch(need.toArray(new String[0]));
    }

    private void onPermResult() {
        permAsked = true;
        if (has(Manifest.permission.CAMERA)) {
            hideMsg();
            startCamera();
        } else {
            showMsg("Camera permission chahiye.\nAllow karo, phir Retry dabao.", "Retry", this::permRetry);
        }
    }

    private void permRetry() {
        if (has(Manifest.permission.CAMERA)) {
            hideMsg();
            startCamera();
        } else if (!permAsked || shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            requestPerms();
        } else {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", getPackageName(), null));
            startActivity(i);
        }
    }

    // =====================================================================
    // camera
    // =====================================================================

    private void startCamera() {
        if (cameraStarting) return;
        if (cameraProvider != null) {
            bindCamera();
            return;
        }
        cameraStarting = true;
        final ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
        f.addListener(() -> {
            cameraStarting = false;
            try {
                cameraProvider = f.get();
            } catch (Exception e) {
                Log.e(TAG, "camera provider", e);
                showMsg("Camera start nahi hua: " + e.getMessage(), "Retry", this::startCamera);
                return;
            }
            initExtensions();
            bindCamera();
        }, mainExec);
    }

    private void initExtensions() {
        try {
            final ListenableFuture<ExtensionsManager> ef =
                    ExtensionsManager.getInstanceAsync(this, cameraProvider);
            ef.addListener(() -> {
                try {
                    extensionsManager = ef.get();
                    if ("PORTRAIT".equals(mode) && recording == null) bindCamera();
                } catch (Exception e) {
                    Log.w(TAG, "extensions unavailable", e);
                }
            }, mainExec);
        } catch (Throwable t) {
            Log.w(TAG, "extensions init failed", t);
        }
    }

    private boolean isBack() {
        return lensFacing == CameraSelector.LENS_FACING_BACK;
    }

    private static String kindFor(String m) {
        if ("VIDEO".equals(m)) return "video";
        if ("PORTRAIT".equals(m)) return "portrait";
        return "photo";
    }

    private int displayRotation() {
        Display d = previewView.getDisplay();
        return d != null ? d.getRotation() : Surface.ROTATION_0;
    }

    private void bindCamera() {
        if (cameraProvider == null || recording != null) return;
        if (previewView.getWidth() == 0) {
            previewView.post(this::bindCamera);
            return;
        }

        CameraSelector base = isBack() ? CameraSelector.DEFAULT_BACK_CAMERA
                : CameraSelector.DEFAULT_FRONT_CAMERA;
        try {
            if (!cameraProvider.hasCamera(base)) {
                CameraSelector other = isBack() ? CameraSelector.DEFAULT_FRONT_CAMERA
                        : CameraSelector.DEFAULT_BACK_CAMERA;
                if (cameraProvider.hasCamera(other)) {
                    lensFacing = isBack() ? CameraSelector.LENS_FACING_FRONT
                            : CameraSelector.LENS_FACING_BACK;
                    base = other;
                } else {
                    showMsg("Is device par camera nahi mila.", null, null);
                    return;
                }
            }
        } catch (CameraInfoUnavailableException e) {
            showMsg("Camera info nahi mili: " + e.getMessage(), "Retry", this::bindCamera);
            return;
        }

        final int rotation = displayRotation();
        final float ratioHw = (float) previewView.getHeight() / previewView.getWidth();
        final int ratio = ratioHw > 1.5f ? AspectRatio.RATIO_16_9 : AspectRatio.RATIO_4_3;
        final String kind = kindFor(mode);

        Preview pv = new Preview.Builder()
                .setTargetAspectRatio(ratio)
                .setTargetRotation(rotation)
                .build();
        pv.setSurfaceProvider(previewView.getSurfaceProvider());

        List<UseCase> cases = new ArrayList<>();
        cases.add(pv);

        if ("video".equals(kind)) {
            Recorder recorder = new Recorder.Builder()
                    .setQualitySelector(QualitySelector.fromOrderedList(
                            Arrays.asList(Quality.FHD, Quality.HD, Quality.SD),
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                    .build();
            videoCapture = VideoCapture.withOutput(recorder);
            videoCapture.setTargetRotation(rotation);
            imageCapture = null;
            cases.add(videoCapture);
        } else {
            imageCapture = new ImageCapture.Builder()
                    .setTargetAspectRatio(ratio)
                    .setTargetRotation(rotation)
                    .setCaptureMode(hdOn ? ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                            : ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setFlashMode(flashOn && isBack() ? ImageCapture.FLASH_MODE_ON
                            : ImageCapture.FLASH_MODE_OFF)
                    .build();
            videoCapture = null;
            cases.add(imageCapture);
        }

        // PORTRAIT: use the phone's real bokeh extension when it exists
        CameraSelector selector = base;
        boolean ext = false;
        if ("portrait".equals(kind) && extensionsManager != null) {
            try {
                if (extensionsManager.isExtensionAvailable(base, ExtensionMode.BOKEH)) {
                    selector = extensionsManager.getExtensionEnabledCameraSelector(base, ExtensionMode.BOKEH);
                    ext = true;
                }
            } catch (Exception e) {
                Log.w(TAG, "bokeh check failed", e);
            }
        }

        // 1) with viewport (what you see = what you get), 2) without, 3) without extension
        ViewPort vp = previewView.getViewPort();
        Camera bound = null;
        Exception last = null;
        for (int attempt = 0; attempt < 3 && bound == null; attempt++) {
            if (attempt == 2 && !ext) break;
            UseCaseGroup.Builder gb = new UseCaseGroup.Builder();
            for (UseCase u : cases) gb.addUseCase(u);
            if (attempt == 0 && vp != null) gb.setViewPort(vp);
            CameraSelector sel = attempt < 2 ? selector : base;
            try {
                cameraProvider.unbindAll();
                bound = cameraProvider.bindToLifecycle(this, sel, gb.build());
                if (attempt == 2) ext = false;
            } catch (Exception e) {
                last = e;
                Log.e(TAG, "bind attempt " + attempt + " failed", e);
            }
        }

        if (bound == null) {
            showMsg("Camera open nahi hua" + (last != null ? ": " + last.getMessage() : "") + "\nRetry dabao.",
                    "Retry", this::bindCamera);
            return;
        }

        camera = bound;
        boundKind = kind;
        extActive = ext;
        updateOverlays();
        applyLook();
        setZoom(zoom);
        applyEv();

        // if no frames arrive, show a message instead of leaving a silent black screen
        final int token = ++bindToken;
        main.postDelayed(() -> {
            if (token != bindToken || isFinishing()) return;
            PreviewView.StreamState st = previewView.getPreviewStreamState().getValue();
            if (st != PreviewView.StreamState.STREAMING) {
                showMsg("Camera preview start nahi hua.\nRetry dabao.", "Retry", this::bindCamera);
            }
        }, 5000);
    }

    // ---------- zoom / ev / focus / look ----------

    private float minZoom() {
        float lo = 1f;
        if (camera != null) {
            ZoomState zs = camera.getCameraInfo().getZoomState().getValue();
            if (zs != null) lo = Math.max(lo, zs.getMinZoomRatio());
        }
        return lo;
    }

    private float maxZoom() {
        float hi = 8f;
        if (camera != null) {
            ZoomState zs = camera.getCameraInfo().getZoomState().getValue();
            if (zs != null) hi = Math.min(hi, zs.getMaxZoomRatio());
        }
        return Math.max(hi, 1f);
    }

    private void setZoom(float z) {
        zoom = Math.max(minZoom(), Math.min(maxZoom(), z));
        if (camera != null) camera.getCameraControl().setZoomRatio(zoom);
        updateZoomUi();
    }

    private void updateZoomUi() {
        int near = 0;
        for (int i = 0; i < ZP.length; i++) {
            if (Math.abs(Math.log(zoom / ZP[i])) < Math.abs(Math.log(zoom / ZP[near]))) near = i;
        }
        for (int i = 0; i < ZP.length; i++) {
            TextView b = zoomBtns[i];
            boolean a = i == near;
            if (a) {
                String num = Math.abs(zoom - ZP[i]) < 0.05f
                        ? String.valueOf((int) ZP[i])
                        : String.format(Locale.US, "%.1f", zoom);
                b.setText(num + "\u00D7");
            } else {
                b.setText(String.valueOf((int) ZP[i]));
            }
            b.setTextColor(a ? ORANGE : Color.WHITE);
            b.setTypeface(null, a ? Typeface.BOLD : Typeface.NORMAL);
        }
        dial.setZoom(zoom);
    }

    private void applyEv() {
        if (camera == null) return;
        ExposureState es = camera.getCameraInfo().getExposureState();
        if (!es.isExposureCompensationSupported()) return;
        float step = es.getExposureCompensationStep().floatValue();
        if (step <= 0f) return;
        Range<Integer> r = es.getExposureCompensationRange();
        int idx = Math.round(ev / step);
        idx = Math.max(r.getLower(), Math.min(r.getUpper(), idx));
        camera.getCameraControl().setExposureCompensationIndex(idx);
    }

    private void focusAt(float x, float y) {
        if (camera == null || pop.getVisibility() == View.VISIBLE) return;
        MeteringPoint pt = previewView.getMeteringPointFactory().createPoint(x, y);
        FocusMeteringAction action = new FocusMeteringAction.Builder(pt,
                FocusMeteringAction.FLAG_AF | FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, TimeUnit.SECONDS)
                .build();
        camera.getCameraControl().startFocusAndMetering(action);

        float s = focusRing.getWidth() > 0 ? focusRing.getWidth() : dp(64);
        focusRing.animate().cancel();
        focusRing.setX(x - s / 2f);
        focusRing.setY(y - s / 2f);
        focusRing.setScaleX(1.4f);
        focusRing.setScaleY(1.4f);
        focusRing.setAlpha(1f);
        focusRing.setVisibility(View.VISIBLE);
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(150).withEndAction(() ->
                focusRing.animate().alpha(0f).setStartDelay(700).setDuration(250)
                        .withEndAction(() -> {
                            focusRing.setVisibility(View.GONE);
                            focusRing.animate().setStartDelay(0);
                        }).start()).start();
    }

    /** Filters / beauty tint the live preview (the saved photo gets the same look). */
    private void applyLook() {
        ColorMatrix cm = Filters.matrixFor(filterIdx, beautyOn);
        if (cm == null) {
            previewView.setLayerType(View.LAYER_TYPE_NONE, null);
        } else {
            Paint p = new Paint();
            p.setColorFilter(new ColorMatrixColorFilter(cm));
            previewView.setLayerType(View.LAYER_TYPE_HARDWARE, p);
        }
    }

    private void updateOverlays() {
        grid.setVisibility(gridOn || "MASTER".equals(mode) ? View.VISIBLE : View.GONE);
        port.setVisibility("PORTRAIT".equals(mode) && !extActive ? View.VISIBLE : View.GONE);
    }

    // =====================================================================
    // modes
    // =====================================================================

    private void setMode(String m) {
        if ("MORE".equals(m)) {
            gridOn = !gridOn;
            updateOverlays();
            return;
        }
        if (recording != null) return;
        mode = m;
        if ("MASTER".equals(m)) gridOn = true;

        for (Map.Entry<String, TextView> en : modeViews.entrySet()) {
            boolean a = en.getKey().equals(mode);
            TextView t = en.getValue();
            t.setTextColor(a ? ORANGE : Color.WHITE);
            t.setTypeface(null, a ? Typeface.BOLD : Typeface.NORMAL);
            t.setBackgroundResource(a ? R.drawable.bg_mode_active : 0);
            t.setCompoundDrawablePadding(dpi(6));
            t.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, a ? R.drawable.ic_tri : 0, 0);
        }
        updateOverlays();
        modesScroll.post(() -> scrollToActiveMode(true));

        if (cameraProvider != null && !kindFor(m).equals(boundKind)) bindCamera();
    }

    private void scrollToActiveMode(boolean smooth) {
        TextView t = modeViews.get(mode);
        if (t == null) return;
        int x = t.getLeft() + t.getWidth() / 2 - modesScroll.getWidth() / 2;
        if (smooth) modesScroll.smoothScrollTo(x, 0);
        else modesScroll.scrollTo(x, 0);
    }

    // =====================================================================
    // capture
    // =====================================================================

    private void onShutter() {
        if (camera == null) {
            toast("Camera abhi ready nahi hai");
            return;
        }
        final boolean video = "VIDEO".equals(mode);
        if (video && recording != null) {
            recording.stop();
            return;
        }
        if (busy) {
            cancelCountdown = true;
            return;
        }
        busy = true;
        cancelCountdown = false;
        countdown(() -> {
            if (video) startRecording();
            else takePhoto();
        });
    }

    private void countdown(final Runnable done) {
        if (timerSec <= 0) {
            done.run();
            return;
        }
        cd.setVisibility(View.VISIBLE);
        final int[] left = {timerSec};
        main.post(new Runnable() {
            @Override
            public void run() {
                if (cancelCountdown) {
                    cd.setVisibility(View.GONE);
                    busy = false;
                    return;
                }
                if (left[0] <= 0) {
                    cd.setVisibility(View.GONE);
                    done.run();
                    return;
                }
                cd.setText(String.valueOf(left[0]--));
                main.postDelayed(this, 1000);
            }
        });
    }

    private void shutterFlash() {
        fl.animate().cancel();
        fl.setAlpha(1f);
        fl.animate().alpha(0f).setDuration(150).start();
    }

    private void takePhoto() {
        final ImageCapture ic = imageCapture;
        if (ic == null) {
            busy = false;
            return;
        }
        final boolean front = !isBack();
        final ColorMatrix cm = Filters.matrixFor(filterIdx, beautyOn);

        final Runnable shoot = () -> {
            ImageCapture.Metadata md = new ImageCapture.Metadata();
            md.setReversedHorizontal(front);

            if (cm == null) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_" + stamp());
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                if (Build.VERSION.SDK_INT >= 29) {
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Camera");
                }
                ImageCapture.OutputFileOptions opts = new ImageCapture.OutputFileOptions.Builder(
                        getContentResolver(), MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                        .setMetadata(md).build();
                ic.takePicture(opts, mainExec, new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(ImageCapture.OutputFileResults r) {
                        busy = false;
                        shutterFlash();
                        Uri u = r.getSavedUri();
                        if (u != null) addItem(u, false);
                    }

                    @Override
                    public void onError(ImageCaptureException e) {
                        busy = false;
                        Log.e(TAG, "takePicture", e);
                        toast("Photo save nahi hui: " + e.getMessage());
                    }
                });
            } else {
                final File tmp = new File(getCacheDir(), "tmp_" + System.currentTimeMillis() + ".jpg");
                ImageCapture.OutputFileOptions opts =
                        new ImageCapture.OutputFileOptions.Builder(tmp).setMetadata(md).build();
                ic.takePicture(opts, mainExec, new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(ImageCapture.OutputFileResults r) {
                        shutterFlash();
                        io.execute(() -> {
                            final Uri u = filterAndSave(tmp, cm);
                            //noinspection ResultOfMethodCallIgnored
                            tmp.delete();
                            main.post(() -> {
                                busy = false;
                                if (u != null) addItem(u, false);
                                else toast("Filter wali photo save nahi hui");
                            });
                        });
                    }

                    @Override
                    public void onError(ImageCaptureException e) {
                        busy = false;
                        Log.e(TAG, "takePicture(filtered)", e);
                        toast("Photo save nahi hui: " + e.getMessage());
                    }
                });
            }
        };

        // front camera has no flash unit: use a white screen flash like the old UI
        if (flashOn && front) {
            fl.animate().cancel();
            fl.setAlpha(1f);
            main.postDelayed(shoot, 250);
        } else {
            shoot.run();
        }
    }

    /** Applies the selected look to a captured JPEG and stores it in the gallery. */
    private Uri filterAndSave(File src, ColorMatrix cm) {
        Bitmap bmp = null, out = null;
        try {
            ExifInterface exif = new ExifInterface(src.getAbsolutePath());
            int rot = exif.getRotationDegrees();
            boolean flip = exif.isFlipped();

            bmp = BitmapFactory.decodeFile(src.getAbsolutePath());
            if (bmp == null) return null;

            Matrix m = new Matrix();
            if (flip) m.postScale(-1f, 1f);
            if (rot != 0) m.postRotate(rot);
            RectF r = new RectF(0, 0, bmp.getWidth(), bmp.getHeight());
            m.mapRect(r);
            m.postTranslate(-r.left, -r.top);

            out = Bitmap.createBitmap(Math.round(r.width()), Math.round(r.height()),
                    Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(out);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
            p.setColorFilter(new ColorMatrixColorFilter(cm));
            canvas.drawBitmap(bmp, m, p);
            bmp.recycle();
            bmp = null;

            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_" + stamp());
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Camera");
            }
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) return null;
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os == null) return null;
                out.compress(Bitmap.CompressFormat.JPEG, 93, os);
            }
            return uri;
        } catch (Throwable t) {
            Log.e(TAG, "filterAndSave", t);
            return null;
        } finally {
            if (bmp != null) bmp.recycle();
            if (out != null) out.recycle();
        }
    }

    // ---------- video ----------

    @SuppressLint("MissingPermission")
    private void startRecording() {
        final VideoCapture<Recorder> vc = videoCapture;
        if (vc == null) {
            busy = false;
            return;
        }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_" + stamp());
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT >= 29) {
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Camera");
        }
        MediaStoreOutputOptions opts = new MediaStoreOutputOptions.Builder(
                getContentResolver(), MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                .setContentValues(cv).build();

        PendingRecording pr = vc.getOutput().prepareRecording(this, opts);
        if (has(Manifest.permission.RECORD_AUDIO)) pr = pr.withAudioEnabled();

        if (flashOn && isBack() && camera != null && camera.getCameraInfo().hasFlashUnit()) {
            camera.getCameraControl().enableTorch(true);
        }
        recording = pr.start(mainExec, event -> onRecordEvent(event));
        setRecordingUi(true);
    }

    private void onRecordEvent(VideoRecordEvent e) {
        if (e instanceof VideoRecordEvent.Status) {
            long sec = e.getRecordingStats().getRecordedDurationNanos() / 1000000000L;
            rec.setText(String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60));
        } else if (e instanceof VideoRecordEvent.Finalize) {
            VideoRecordEvent.Finalize f = (VideoRecordEvent.Finalize) e;
            recording = null;
            busy = false;
            setRecordingUi(false);
            if (camera != null) camera.getCameraControl().enableTorch(false);
            Uri u = f.getOutputResults().getOutputUri();
            if (!f.hasError()) {
                addItem(u, true);
            } else {
                Log.e(TAG, "video finalize error " + f.getError(), f.getCause());
                try {
                    if (u != null && !Uri.EMPTY.equals(u)) getContentResolver().delete(u, null, null);
                } catch (Exception ignored) {
                    // nothing to clean up
                }
                toast("Video save nahi hua (error " + f.getError() + ")");
            }
        }
    }

    private void setRecordingUi(boolean on) {
        rec.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) rec.setText("00:00");
        if (on) {
            shutterFill.setShape(GradientDrawable.RECTANGLE);
            shutterFill.setCornerRadius(dp(14));
            shutterFill.setColor(0xFFFF3333);
            shi.animate().scaleX(0.55f).scaleY(0.55f).setDuration(200).start();
        } else {
            shutterFill.setShape(GradientDrawable.OVAL);
            shutterFill.setColor(ORANGE);
            shi.animate().scaleX(1f).scaleY(1f).setDuration(200).start();
        }
    }

    // =====================================================================
    // gallery
    // =====================================================================

    private void addItem(Uri uri, boolean video) {
        final Item it = new Item(uri, video, System.currentTimeMillis());
        items.add(0, it);
        updateThumb();
        loadThumbAsync(it);
    }

    private void loadThumbAsync(final Item it) {
        io.execute(() -> {
            final Bitmap b = it.video ? videoFrame(it.uri) : decodeSampled(it.uri, 256);
            main.post(() -> {
                it.thumb = b;
                if (!items.isEmpty() && items.get(0) == it) updateThumb();
            });
        });
    }

    private void updateThumb() {
        if (items.isEmpty()) th.setImageDrawable(null);
        else th.setImageBitmap(items.get(0).thumb);
    }

    private void loadExisting() {
        if (Build.VERSION.SDK_INT < 29) return;
        io.execute(() -> {
            final List<Item> found = new ArrayList<>();
            queryInto(found, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, "Pictures/Camera/");
            queryInto(found, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, "Movies/Camera/");
            Collections.sort(found, (a, b) -> Long.compare(b.date, a.date));
            main.post(() -> {
                int n = 0;
                for (Item f : found) {
                    boolean dup = false;
                    for (Item e : items) if (e.uri.equals(f.uri)) dup = true;
                    if (!dup && n++ < 60) items.add(f);
                }
                if (!items.isEmpty()) {
                    updateThumb();
                    if (items.get(0).thumb == null) loadThumbAsync(items.get(0));
                }
            });
        });
    }

    private void queryInto(List<Item> out, Uri base, boolean video, String relPath) {
        String[] proj = {MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATE_ADDED};
        try (Cursor c = getContentResolver().query(base, proj,
                MediaStore.MediaColumns.RELATIVE_PATH + "=?", new String[]{relPath},
                MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            if (c == null) return;
            int idIdx = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
            int dIdx = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED);
            int n = 0;
            while (c.moveToNext() && n++ < 60) {
                out.add(new Item(ContentUris.withAppendedId(base, c.getLong(idIdx)), video,
                        c.getLong(dIdx) * 1000L));
            }
        } catch (Exception e) {
            Log.w(TAG, "query failed", e);
        }
    }

    private void showViewer() {
        if (items.isEmpty()) return;
        if (cur >= items.size()) cur = 0;
        final Item it = items.get(cur);
        stopViewerVideo();
        pm.removeAllViews();
        pop.setVisibility(View.VISIBLE);

        if (!it.video) {
            final ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            pm.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            io.execute(() -> {
                final Bitmap b = decodeSampled(it.uri, 2048);
                main.post(() -> {
                    if (cur < items.size() && items.get(cur) == it) iv.setImageBitmap(b);
                });
            });
        } else {
            VideoView vv = new VideoView(this);
            pm.addView(vv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER));
            MediaController mc = new MediaController(this);
            mc.setAnchorView(vv);
            vv.setMediaController(mc);
            vv.setVideoURI(it.uri);
            vv.setOnPreparedListener(mp -> mp.start());
        }
    }

    private void stopViewerVideo() {
        for (int i = 0; i < pm.getChildCount(); i++) {
            View c = pm.getChildAt(i);
            if (c instanceof VideoView) ((VideoView) c).stopPlayback();
        }
    }

    private void closeViewer() {
        stopViewerVideo();
        pm.removeAllViews();
        pop.setVisibility(View.GONE);
    }

    private void deleteCurrent() {
        if (items.isEmpty() || cur >= items.size()) {
            closeViewer();
            return;
        }
        Item it = items.get(cur);
        try {
            getContentResolver().delete(it.uri, null, null);
        } catch (Exception e) {
            Log.w(TAG, "delete failed", e);
            toast("Delete nahi ho paya");
            return;
        }
        items.remove(cur);
        updateThumb();
        if (items.isEmpty()) {
            closeViewer();
        } else {
            cur = Math.min(cur, items.size() - 1);
            showViewer();
        }
    }

    /** Decodes an image (with EXIF rotation) so that its biggest side is about maxDim. */
    private Bitmap decodeSampled(Uri uri, int maxDim) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream is = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(is, null, o);
            }
            int big = Math.max(o.outWidth, o.outHeight);
            int s = 1;
            while (big / (s * 2) >= maxDim) s *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = s;
            Bitmap b;
            try (InputStream is = getContentResolver().openInputStream(uri)) {
                b = BitmapFactory.decodeStream(is, null, o);
            }
            if (b == null) return null;

            int rot = 0;
            boolean flip = false;
            try (InputStream is = getContentResolver().openInputStream(uri)) {
                ExifInterface ex = new ExifInterface(is);
                rot = ex.getRotationDegrees();
                flip = ex.isFlipped();
            } catch (Exception ignored) {
                // no exif, use as is
            }
            if (rot != 0 || flip) {
                Matrix m = new Matrix();
                if (flip) m.postScale(-1f, 1f);
                if (rot != 0) m.postRotate(rot);
                Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                if (r != b) b.recycle();
                b = r;
            }
            return b;
        } catch (Throwable t) {
            Log.w(TAG, "decodeSampled", t);
            return null;
        }
    }

    private Bitmap videoFrame(Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, uri);
            Bitmap f = r.getFrameAtTime(0);
            if (f == null) return null;
            int big = Math.max(f.getWidth(), f.getHeight());
            if (big > 400) {
                float k = 400f / big;
                Bitmap s = Bitmap.createScaledBitmap(f, Math.round(f.getWidth() * k),
                        Math.round(f.getHeight() * k), true);
                if (s != f) f.recycle();
                f = s;
            }
            return f;
        } catch (Throwable t) {
            Log.w(TAG, "videoFrame", t);
            return null;
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
                // ignore
            }
        }
    }

    // =====================================================================
    // small helpers
    // =====================================================================

    private void styleChip() {
        boolean on = timerSec > 0;
        bTm.setSelected(on);
        tmv.setText(on ? timerSec + "s" : "Off");
        int c = on ? ON_ORANGE : Color.WHITE;
        tmv.setTextColor(c);
        tmi.setColorFilter(c, PorterDuff.Mode.SRC_IN);
    }

    private void tint(ImageView v, boolean on) {
        v.setColorFilter(on ? ORANGE : Color.WHITE, PorterDuff.Mode.SRC_IN);
    }

    private void showMsg(String text, String btn, final Runnable action) {
        msgText.setText(text);
        if (btn == null || action == null) {
            msgBtn.setVisibility(View.GONE);
        } else {
            msgBtn.setVisibility(View.VISIBLE);
            msgBtn.setText(btn);
            msgBtn.setOnClickListener(v -> {
                hideMsg();
                action.run();
            });
        }
        msg.setVisibility(View.VISIBLE);
    }

    private void hideMsg() {
        msg.setVisibility(View.GONE);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private int dpi(float v) {
        return Math.round(dp(v));
    }
}
