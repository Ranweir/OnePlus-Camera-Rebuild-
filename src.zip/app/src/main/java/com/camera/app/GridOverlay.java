package com.camera.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** Rule-of-thirds grid. */
public class GridOverlay extends View {
    private final Paint p = new Paint();

    public GridOverlay(Context c) { this(c, null); }

    public GridOverlay(Context c, AttributeSet a) {
        super(c, a);
        p.setColor(0x44FFFFFF);
        p.setStrokeWidth(getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        c.drawLine(w / 3f, 0, w / 3f, h, p);
        c.drawLine(2f * w / 3f, 0, 2f * w / 3f, h, p);
        c.drawLine(0, h / 3f, w, h / 3f, p);
        c.drawLine(0, 2f * h / 3f, w, 2f * h / 3f, p);
    }
}
